export class ProductCategory {
  id: number;
  categoryName:string
}
